﻿namespace MyAcademyChainOfResponsibility.Models
{
    public class CustomerProcessViewModel
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public string EmployeeName { get; set; }
        public string Description { get; set; }
    }
}
