# MyAcademy Chain Of Responsibility Mini Project

Chain of Responsibility design pattern kullanarak yapmış olduğum tek katmanlı bir mini atm projesidir. Bankadan para çekmek isteyen müşteri paranın limitine göre bankanın departmanlarına yönlendirilir.

![image](https://github.com/esincaglakiral/MyAcademyChainOfResponsibility/assets/68962573/7e4b8730-3666-4cc0-b062-a399cb125e5f)

![image](https://github.com/esincaglakiral/MyAcademyChainOfResponsibility/assets/68962573/dc0f12d8-adc7-44c8-b8a7-072b393c496c)

-----------------------------------------------------------------------------------------------------------------------------------------
![image](https://github.com/esincaglakiral/MyAcademyChainOfResponsibility/assets/68962573/5d3867d0-8d7c-493b-b14f-383b1f1eb8e3)

![image](https://github.com/esincaglakiral/MyAcademyChainOfResponsibility/assets/68962573/725559ac-92cd-4152-a8db-3c0e255b2563)
